SET TERM !! ;
CREATE PROCEDURE GETFILES (HOST varchar(50), LOGIN varchar(50), PASS varchar(50), PORT smallint, PASSIVE smallint)
RETURNS (
  VHOST          INTEGER,
  V_ALL          VARCHAR(600),
  V_PATH	 VARCHAR(1000),
  V_ATR	         VARCHAR(10),
  V_USER	 INTEGER,
  V_GROUP        INTEGER,
  V_SIZE	 INTEGER,
  V_DATE         DATE,
  V_TIME	 TIME,
  V_NAME	 VARCHAR(1000))
AS
  declare variable VLOGIN INTEGER;
  declare variable VCOUNT INTEGER;
  declare variable VPORT  VARCHAR(20);
BEGIN
  if((:HOST='')or(:HOST is Null)or(:LOGIN='')or(:LOGIN is Null))then Exit;
  select * from GETHOST(:HOST, :PORT, :PASSIVE) into :VHOST;
  select * from GETLOGIN(:HOST, :LOGIN, :PASS, :PORT, :PASSIVE) into :VLOGIN;
  VPORT=Cast(Port as VARCHAR(20));

  for select * from ftp_files where(HOST=:VHOST)into
    :VHOST, :V_ALL, :V_PATH, :V_ATR, :V_USER, :V_GROUP, :V_SIZE, :V_DATE, :V_TIME, :V_NAME do
  begin
    select count(LOGIN) from ftp_dirs where(LOGIN=:VLOGIN)and(:V_ALL starting with A_ALL)into :VCOUNT;
    V_PATH='<a href="ftp://'||LOGIN||':'||PASS||'@'||HOST||':'||VPORT||V_PATH||'" title="������� �����" target="_blank">'||V_PATH||'</a>';
    V_NAME='<a href="ftp://'||LOGIN||':'||PASS||'@'||HOST||':'||VPORT||V_ALL||'" title="���������" target="_blank">'||V_NAME||'</a>';
    if(VCOUNT>0)then suspend;
  end
END !!
SET TERM ; !!

SET TERM !! ;
create PROCEDURE EV_GEN (TEXT VARCHAR(100))
RETURNS
AS
BEGIN
  post_event text;
END !!
SET TERM ; !!

SET TERM !! ;
CREATE TRIGGER READ_TIME_SCAN FOR TIME_SCAN
after update
AS
BEGIN
  post_event 'TIME_SCAN';
END !!
SET TERM ; !!

SET TERM !! ;
CREATE TRIGGER READ_TIME_SCAN2 FOR TIME_SCAN
after INSERT
AS
BEGIN
  post_event 'TIME_SCAN';
END !!
SET TERM ; !!
