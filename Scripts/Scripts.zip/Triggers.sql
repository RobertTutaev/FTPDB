SET TERM !! ;
CREATE TRIGGER FTP_HOST_BD FOR FTP_HOST
ACTIVE BEFORE delete POSITION 0
as
begin
  delete from ftp_files where host=ftp_host.kod;
  delete from ftp_scan1 where host=ftp_host.kod;
  delete from ftp_login where host=ftp_host.kod;
end!!
SET TERM ; !!

SET TERM !! ;
CREATE TRIGGER FTP_LOGIN_BD FOR FTP_LOGIN
ACTIVE BEFORE delete POSITION 0
as
begin
  delete from ftp_dirs  where login=ftp_login.kod;
  delete from ftp_scan2 where login=ftp_login.kod;
end!!
SET TERM ; !!

SET TERM !! ;
CREATE TRIGGER FTP_LOGIN_BU FOR FTP_LOGIN
ACTIVE BEFORE update POSITION 0
as
begin
  if(new.act=2)then
    update FTP_LOGIN set act=1 where(host=new.host)and((act=2)or(act is null));
end!!
SET TERM ; !!

SET TERM !! ;
CREATE TRIGGER FTP_LOGIN_BI FOR FTP_LOGIN
ACTIVE BEFORE INSERT POSITION 0
as
begin
  if(new.act=2)then
    update FTP_LOGIN set act=1 where(host=new.host)and((act=2)or(act is null));
end!!
SET TERM ; !!

SET TERM !! ;
CREATE TRIGGER OPTIONS_BI FOR OPTIONS
ACTIVE BEFORE INSERT POSITION 0
as
begin
  delete from OPTIONS;
end!!
SET TERM ; !!

SET TERM !! ;
CREATE TRIGGER FTP_SCAN1_AI FOR FTP_SCAN1
ACTIVE AFTER INSERT POSITION 0
as
  declare variable cnt integer;
begin
  select lrl from options into :cnt;
  delete from FTP_SCAN1 where n<new.n-:cnt+1;
end!!
SET TERM ; !!
